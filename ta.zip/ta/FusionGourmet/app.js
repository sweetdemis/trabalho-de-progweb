const express = require("express")
const mongoose = require("mongoose")
const passport = require("passport")
const LocalStrategy = require("passport-local")
const expressSession = require("express-session")
const request = require("request")
const axios = require("axios")
const ejs = require("ejs")
const app = express()
const path = require("path")
const User = require("./models/user")

const key_api = "a51430a6da564c96be47ca64a0955a66"

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({extended:false}))
app.use(expressSession({
    secret: "meu_segredo",
    resave: false,
    saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
passport.use(new LocalStrategy(User.authenticate()))
passport.serializeUser(User.serializeUser())
passport.deserializeUser(User.deserializeUser())

mongoose.connect("mongodb://127.0.0.1/FusionGourmet")
    .then(() => {
    console.log("Conexão estabelecida com o banco!")
    })
    .catch(err => {
    console.log("Erro ao conectar com o banco...")
    console.log(err)
    })

app.get("/register", (req, res) => {
    res.render("register")
})

app.post("/register", (req, res) => {
    User.resgister(new User({username: req.body.username}), req.body.password, (err, user) => {
        if(err) {
            console.log(err)
            res.render("register")
        } else {
            passport.authenticate("local")(req, res, () => {
                res.redirect("/home")
            })
        }
    })
})

const isLoggedIn = (req, res, next) => {
    if(req.isAuthenticated()){
        return next()
    }
    res.redirect("/login")
}

app.get("/login", (req, res) => {
    res.redirect("login")
})

app.post("/login", 
    passport.authenticate('local', {failureRedirect: '/login', failureMessage: true}),
    function(req, res) {
        res.redirect
    }
)

app.get('/', (req, res) => {
    res.render('home')
})

app.post('/search', async(req, res) => {

   const {query} = req.body;
   const response = await axios.get(`https://api.spoonacular.com/recipes/complexSearch?query=${query}&apiKey=${key_api}`)
   const recipes = response.data.results;
   res.render('results', {recipes})
})

app.get('/recipe/:id', async(req,res)=>{
    const {id} = req.params;
    const response = await axios.get(`https://api.spoonacular.com/recipes/${id}/information?apiKey=${key_api}`)
    const recipe = response.data;
    res.render('recipe',{recipe})
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})