const express = require("express")
const request = require("request")
const app = express()
const path = require("path")

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))

app.get("/", (req, res) => {
    res.render("index")
})

app.get('/busca', (req, res) => {
    let {busca, cozinha} = req.query
    if (!tipo) tipo = ""
    let resposta = {}
    request("https://api.spoonacular.com/recipes/complexSearch/cuisine="+cozinha+busca, (error, response, body) => {
        if(!error && response.statusCode == 200){
            resposta = JSON.parse(body)
        }
        res.render('resultadoBusca', {resposta})
    })
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})