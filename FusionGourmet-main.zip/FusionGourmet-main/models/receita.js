const {mongoose} = require ('../db')

const receitaSchema = new mongoose.Schema({
    query: String
})

const Receita = mongoose.model("Receita", receitaSchema)

module.exports = Receita