const express = require("express")
const axios = require("axios")
const ejs = require("ejs")
const app = express()
const path = require("path")
const passport = require("passport")
const LocalStrategy = require("passport-local")
const expressSession = require("express-session")
const Receita = require('./models/receita')
const User = require('./models/user')
const {mongoose} = require ('./db')

const key_api = "d62185cdf2fa4e5c90a34f61cdf2c437"

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({extended: false}))
app.use(expressSession({
    secret: "infoProfile", resave: false, saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
passport.use(new LocalStrategy(User.authenticate()))
passport.serializeUser(User.serializeUser())
passport.deserializeUser(User.deserializeUser())

app.get('/', async (req, res) => {
    const responseVegetarian = await axios.get(` https://api.spoonacular.com/recipes/random?number=4&tags=vegetarian&apiKey=${key_api}`)
    const vegetarianRecipes = responseVegetarian.data.recipes;

    const responseCake = await axios.get(` https://api.spoonacular.com/recipes/random?number=4&tags=breakfast&apiKey=${key_api}`)
    const cakeRecipes = responseCake.data.recipes;


    res.render('home', {cakeRecipes, vegetarianRecipes})
})
app.get('/search', (req, res) => {
    res.render('results')
})

app.post('/search', async (req, res) => {

    const {query} = req.body;
    const response = await axios.get(`https://api.spoonacular.com/recipes/complexSearch?query=${query}&apiKey=${key_api}`)
    const recipes = response.data.results;
    res.render('results', {recipes})
})


app.get('/recipe/:id', async (req, res) => {
    const {id} = req.params;
    const response = await axios.get(`https://api.spoonacular.com/recipes/${id}/information?apiKey=${key_api}`)
    const recipe = response.data;
    res.render('recipe', {recipe})
})

app.post("/recipe/:id", async (req, res) => {
    const {id} = req.params
    const recipes = response.datas.results
    for (item of recipes.items) {
        if (item.id == id) {
            const recipe = item.query
            const recipeFav = await Receita.find({query: recipe.query})
            if (recipeFav.length == 0) {
                const newRecipe = new Receita({query: recipe.query})
                await newRecipe.save()
                console.log("Receita salva!")
            } else {
                console.log("A receita já está nas suas favoritas!")
            }
        }
    }    
})
    


app.get("/register", (req, res) => {
    res.render("register")
})

app.post("/register", async (req, res) => {
    User.register(new User({username: req.body.username, email: req.body.email}), req.body.password, (err, user) => {
        if(err) {
            console.log(err)
            res.render("register")
        } else {
            passport.authenticate("local")(req, res, () => {
                res.redirect("/infoProfile")
            })
        }
    })
})

const isLoggedIn = (req, res, next) => {
    if(req.isAuthenticated()){
        return next()
    }
    res.redirect("/login")
}

app.get('/login', isLoggedIn, (req, res) => {
    res.render('login')
})

app.post('/login', passport.authenticate('local', {failureRedirect:'/login', failureMessage: true}), 
    function(req, res) {
        res.redirect('/infoProfile')
    })

app.get("/logout", (req, res) => {
    req.logOut(() => {
        console.log("Sessão encerrada")
    }) 
    res.redirect('/')
})

app.get('/infoProfile', isLoggedIn, (req, res) => { //isLoggedIn
    res.render('infoProfile')
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})