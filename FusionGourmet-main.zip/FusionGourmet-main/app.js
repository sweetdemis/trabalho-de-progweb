const express = require("express")
const request = require("request")
const axios = require("axios")
const ejs = require("ejs")
const app = express()
const path = require("path")
const mongoose = require("mongoose")
const expressSssion = require("express-session")
const passport = require("passport")
const LocalStrategy = require ("passport-local")
const user = require('./models/user')


const key_api = "d62185cdf2fa4e5c90a34f61cdf2c437"

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({ extended: false }))

app.use(session({secret:'senha', resave: false, saveUninitialized: false}));
app.use(passport.initialize())
app.use(passport.session())
passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser(User.serializeUser())
passport.deserializeUser(User.deserializeUser)

mongoose.connect("mongodb://localhost/FusionGourmet", {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => {
        console.log("conexão estabelecida com o banco")
    })
    .catch(err => {console.log("erro ao conectar com o banco" + err)})

const isLoggedIn = (req, res, next) => {
    if(req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login')
}

app.get('/', async (req, res) => {
    const responseVegetarian = await axios.get(` https://api.spoonacular.com/recipes/random?number=4&tags=vegetarian&apiKey=${key_api}`)
    const vegetarianRecipes = responseVegetarian.data.recipes;

    const responseCake = await axios.get(` https://api.spoonacular.com/recipes/random?number=4&tags=breakfast&apiKey=${key_api}`)
    const cakeRecipes = responseCake.data.recipes;


    res.render('home', { cakeRecipes, vegetarianRecipes })
})
app.get('/search', (req, res) => {
    res.render('results')
})

app.post('/search', async (req, res) => {

    const {query} = req.body;
    const response = await axios.get(`https://api.spoonacular.com/recipes/complexSearch?query=${query}&apiKey=${key_api}`)
    const recipes = response.data.results;
    res.render('results', { recipes })
})


app.get('/recipe/:id', async (req, res) => {
    const { id } = req.params;
    const response = await axios.get(`https://api.spoonacular.com/recipes/${id}/information?apiKey=${key_api}`)
    const recipe = response.data;
    res.render('recipe', { recipe })
})

app.get('/perfil', (req, res) => {
    res.render('profile')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/register', (req, res) => {
    res.render('register')
})

app.post('register', (req, res) => {
    User.register(new User({username: req.body.name}), req.body.passport, (err, user) => {
        if(err) {
            console.log(err)
            res.render('register')
        } else {
            passport.authenticate("local")(req, res, () => {
                res.redirect("/infoProfile")
            })
        }
    })
})

app.get('/infoProfile', isLoggedIn, (req, res) => {
    res.render('infoProfile')
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})